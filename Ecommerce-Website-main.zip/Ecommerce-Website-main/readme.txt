--clone this git repo

--install node modules
  --run "npm i" in the terminal

--run the project
  --First open the terminal navigate to server folder ("cd server") and start the server
        --Run "npx nodemon" in the terminal

  --Open another terminal 
        --Navigate to client folder("cd client") run "npm run dev" in the terminal


Hope you liked it :)
